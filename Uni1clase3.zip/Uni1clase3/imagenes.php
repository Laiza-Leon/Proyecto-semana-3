<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <title>Mi proyecto Php</title>
</head>
<body>
<div class="jumbotron text-center">
     <h1>SEMANA 3 Trabajando interfaces con Bootstrap</h1>
    <p> Este sitio incluye bootstrap y es un  ejemplo del diseño responsive.</p>
     </div>

    <br>
    <div class="container">
    <nav class="navbar navbar-expand-sm bg-dark">

    <!--Links-->
    <u1 class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="./index.php">Tablas</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Imagenes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./alertas.php">Alertas</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./botones.php">Botones</a>
      </li>
     </u1>  

     </nav> 
    </div>
    <br>
    <div class="container">
         <h1>EJEMPLO DE PROYECTO EN REPOSITORIO</h1>
        <h2>HOLA ESTE ES MI EJEMPLO TRABAJANDO CON IMAGENES</h2>
        <img src="./imagenes/foto2.jpg" class="rounded" alt="Ford Raptor"  title="Raptor"/> 
        <img src="./imagenes/foto5.jpg" class="rounded-circle" alt="Ford Raptor" title="imagen2"/>
        <img src="./imagenes/foto7.jpg" class="img-thumbnail" alt="Ford Raptor 2019" title="Ford Raptor 2019"/> 
        <img src="./imagenes/foto8.jpg" class="img-fluid" alt="Ford Raptor Deportiva" title="Ford Raptor Deportiva"/>  
        <br/>
        <img src="./imagenes/foto9.jpg" alt="Ford Raptor Deportiva" title="Ford Raptor Deportiva" class="img-fluid"  style="width:270px;heigth:270px"/>  
        <br>
        <a href="./index.php">
          <img src="./imagenes/foto1"  alt="Ford Raptor"  title="Ir al inicio" />
        </a> 
        <a href="http://www.google.com">
          <img src="./imagenes/foto3"  alt="Ford Raptor"  title="Ir al Google" />
        </a>     
    </div>
</body>
</html>